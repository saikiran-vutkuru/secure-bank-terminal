typedef unsigned int u32;
typedef unsigned char u8;
typedef char s8;
typedef int s32;
typedef float f32;
